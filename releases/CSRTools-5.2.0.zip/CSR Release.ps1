﻿[CmdletBinding()]
param(
    [ValidateSet('Publish','Install','Prepare','Verify','Check','CloudSync','CloudConnect','CloudDisconnect','CloudAccounts','CloudRelease')][string]$Mode,
    [string]$InstallRoot = $PSScriptRoot,
    [string]$RepositoryPath,
    [string]$NextVersion,
    [string]$NotesPath,
    [string]$ManifestPath,
    [string]$PackagePath,
    [int]$WaitPid = 0,
    [string]$AutoHotkeyPath,
    [string]$CompilerPath,
    [string]$BasePath,
    [string]$DataRoot,
    [string]$InputPath,
    [string]$ResultPath,
    [switch]$UpdatePackage
)
$CSRCloudEmbedded = '77u/W0NtZGxldEJpbmRpbmcoKV0NCnBhcmFtKA0KICAgIFtWYWxpZGF0ZVNldCgnU3luYycsJ0Nvbm5lY3QnLCdEaXNjb25uZWN0JywnQWNjb3VudHMnLCdSZWxlYXNlJywnTGlicmFyeScpXVtzdHJpbmddJE1vZGUgPSAnTGlicmFyeScsDQogICAgW3N0cmluZ10kRGF0YVJvb3QsIFtzdHJpbmddJElucHV0UGF0aCwgW3N0cmluZ10kUmVzdWx0UGF0aCwNCiAgICBbc3RyaW5nXSRJbnN0YWxsUm9vdCA9ICRQU1NjcmlwdFJvb3QsIFtzdHJpbmddJFBhY2thZ2VQYXRoDQopDQokRXJyb3JBY3Rpb25QcmVmZXJlbmNlID0gJ1N0b3AnDQpTZXQtU3RyaWN0TW9kZSAtVmVyc2lvbiBMYXRlc3QNCkFkZC1UeXBlIC1Bc3NlbWJseU5hbWUgU3lzdGVtLlNlY3VyaXR5DQokc2NyaXB0OkFwaSA9ICdodHRwczovL2FwaS5naXRodWIuY29tL3JlcG9zL0lMb3ZlWW91QmV2L0NTUi1Ub29scycNCiRzY3JpcHQ6VG9rZW4gPSAnJw0KJHNjcmlwdDpVdGY4ID0gW1RleHQuVVRGOEVuY29kaW5nXTo6bmV3KCRmYWxzZSwgJHRydWUpDQojIFNoYXJlZCBjbGllbnQgZW5jcnlwdGlvbiBkZXRlcnMgY2FzdWFsIHJlYWRpbmc7IGl0IGlzIE5PVCBhIHNlcnZlciBzZWN1cml0eSBib3VuZGFyeS4NCiMgR2l0SHViIGNyZWRlbnRpYWxzIGFyZSBzZXBhcmF0ZSBhbmQgTkVWRVIgaW5jbHVkZWQgaW4gdGhpcyBrZXkgb3IgZGlzdHJpYnV0aW9uLg0KJHNjcmlwdDpFbnZlbG9wZUtleSA9ICdEdk9wc1FOL0Zzb2VnQkhsT20vd0xMK0ZnSXNnOElTVkh6Q3RLdjBwckRYZlpyRVFsTE5BMWFhdThVWVdoa0s3aVNiN2t2NW9peUp2NkJUMSt3RTJqdz09Jw0KZnVuY3Rpb24gUHJvdGVjdC1Mb2NhbChbc3RyaW5nXSRUZXh0LCBbc3RyaW5nXSRQYXRoKSB7DQogICAgJGJ5dGVzID0gW1NlY3VyaXR5LkNyeXB0b2dyYXBoeS5Qcm90ZWN0ZWREYXRhXTo6UHJvdGVjdCgkc2NyaXB0OlV0ZjguR2V0Qnl0ZXMoJFRleHQpLCRudWxsLFtTZWN1cml0eS5DcnlwdG9ncmFwaHkuRGF0YVByb3RlY3Rpb25TY29wZV06OkN1cnJlbnRVc2VyKQ0KICAgICR0ZW1wID0gJFBhdGggKyAnLicgKyBbZ3VpZF06Ok5ld0d1aWQoKS5Ub1N0cmluZygnTicpDQogICAgW0lPLkZpbGVdOjpXcml0ZUFsbEJ5dGVzKCR0ZW1wLCRieXRlcykNCiAgICBpZiAoW0lPLkZpbGVdOjpFeGlzdHMoJFBhdGgpKSB7IFtJTy5GaWxlXTo6UmVwbGFjZSgkdGVtcCwkUGF0aCwoJFBhdGggKyAnLnByZXZpb3VzJykpIH0gZWxzZSB7IFtJTy5GaWxlXTo6TW92ZSgkdGVtcCwkUGF0aCkgfQ0KfQ0KZnVuY3Rpb24gVW5wcm90ZWN0LUxvY2FsKFtzdHJpbmddJFBhdGgpIHsNCiAgICByZXR1cm4gJHNjcmlwdDpVdGY4LkdldFN0cmluZyhbU2VjdXJpdHkuQ3J5cHRvZ3JhcGh5LlByb3RlY3RlZERhdGFdOjpVbnByb3RlY3QoW0lPLkZpbGVdOjpSZWFkQWxsQnl0ZXMoJFBhdGgpLCRudWxsLFtTZWN1cml0eS5DcnlwdG9ncmFwaHkuRGF0YVByb3RlY3Rpb25TY29wZV06OkN1cnJlbnRVc2VyKSkNCn0NCmZ1bmN0aW9uIFByb3RlY3QtU2hhcmVkKFtvYmplY3RdJFN0YXRlKSB7DQogICAgJGtleSA9IFtDb252ZXJ0XTo6RnJvbUJhc2U2NFN0cmluZygkc2NyaXB0OkVudmVsb3BlS2V5KQ0KICAgICRhZXMgPSBbU2VjdXJpdHkuQ3J5cHRvZ3JhcGh5LkFlc106OkNyZWF0ZSgpDQogICAgJG1hYyA9IFtTZWN1cml0eS5DcnlwdG9ncmFwaHkuSE1BQ1NIQTI1Nl06Om5ldyhbYnl0ZVtdXSRrZXlbMzIuLjYzXSkNCiAgICB0cnkgew0KICAgICAgICAkYWVzLktleSA9IFtieXRlW11dJGtleVswLi4zMV07ICRhZXMuR2VuZXJhdGVJVigpDQogICAgICAgICRwbGFpbiA9ICRzY3JpcHQ6VXRmOC5HZXRCeXRlcygoJFN0YXRlIHwgQ29udmVydFRvLUpzb24gLURlcHRoIDggLUNvbXByZXNzKSkNCiAgICAgICAgJGNpcGhlciA9ICRhZXMuQ3JlYXRlRW5jcnlwdG9yKCkuVHJhbnNmb3JtRmluYWxCbG9jaygkcGxhaW4sMCwkcGxhaW4uTGVuZ3RoKQ0KICAgICAgICAkYm9keSA9ICdDU1JTSEFSRUQxOicgKyBbQ29udmVydF06OlRvQmFzZTY0U3RyaW5nKCRhZXMuSVYpICsgJzonICsgW0NvbnZlcnRdOjpUb0Jhc2U2NFN0cmluZygkY2lwaGVyKQ0KICAgICAgICAkZW52ZWxvcGUgPSAkYm9keSArICc6JyArIFtDb252ZXJ0XTo6VG9CYXNlNjRTdHJpbmcoJG1hYy5Db21wdXRlSGFzaCgkc2NyaXB0OlV0ZjguR2V0Qnl0ZXMoJGJvZHkpKSkNCiAgICAgICAgaWYgKCRlbnZlbG9wZS5MZW5ndGggLWd0IDEwMDAwMDApIHsgdGhyb3cgJ1NoYXJlZCBhY2NvdW50IGZpbGUgZXhjZWVkcyB0aGUgR2l0SHViIGFjY291bnQtZmlsZSBsaW1pdC4nIH0NCiAgICAgICAgcmV0dXJuICRlbnZlbG9wZQ0KICAgIH0gZmluYWxseSB7ICRhZXMuRGlzcG9zZSgpOyAkbWFjLkRpc3Bvc2UoKSB9DQp9DQpmdW5jdGlvbiBVbnByb3RlY3QtU2hhcmVkKFtzdHJpbmddJEVudmVsb3BlKSB7DQogICAgaWYgKCRFbnZlbG9wZS5MZW5ndGggLWd0IDIwOTcxNTIpIHsgdGhyb3cgJ1NoYXJlZCBhY2NvdW50IGZpbGUgaXMgdG9vIGxhcmdlLicgfQ0KICAgICRwYXJ0cyA9ICRFbnZlbG9wZS5UcmltKCkuU3BsaXQoJzonKQ0KICAgIGlmICgkcGFydHMuQ291bnQgLW5lIDQgLW9yICRwYXJ0c1swXSAtbmUgJ0NTUlNIQVJFRDEnKSB7IHRocm93ICdJbnZhbGlkIHNoYXJlZCBhY2NvdW50IGZpbGUuJyB9DQogICAgJGtleSA9IFtDb252ZXJ0XTo6RnJvbUJhc2U2NFN0cmluZygkc2NyaXB0OkVudmVsb3BlS2V5KQ0KICAgICRtYWMgPSBbU2VjdXJpdHkuQ3J5cHRvZ3JhcGh5LkhNQUNTSEEyNTZdOjpuZXcoW2J5dGVbXV0ka2V5WzMyLi42M10pDQogICAgJGFlcyA9IFtTZWN1cml0eS5DcnlwdG9ncmFwaHkuQWVzXTo6Q3JlYXRlKCkNCiAgICB0cnkgew0KICAgICAgICAkZXhwZWN0ZWQgPSAkbWFjLkNvbXB1dGVIYXNoKCRzY3JpcHQ6VXRmOC5HZXRCeXRlcygoJHBhcnRzWzAuLjJdIC1qb2luICc6JykpKQ0KICAgICAgICAkYWN0dWFsID0gW0NvbnZlcnRdOjpGcm9tQmFzZTY0U3RyaW5nKCRwYXJ0c1szXSk7ICRkaWZmID0gJGFjdHVhbC5MZW5ndGggLWJ4b3IgJGV4cGVjdGVkLkxlbmd0aA0KICAgICAgICBpZiAoJGFjdHVhbC5MZW5ndGggLWVxICRleHBlY3RlZC5MZW5ndGgpIHsgZm9yICgkaT0wOyRpIC1sdCAkYWN0dWFsLkxlbmd0aDskaSsrKSB7ICRkaWZmID0gJGRpZmYgLWJvciAoJGFjdHVhbFskaV0gLWJ4b3IgJGV4cGVjdGVkWyRpXSkgfSB9DQogICAgICAgIGlmICgkZGlmZiAtbmUgMCkgeyB0aHJvdyAnU2hhcmVkIGFjY291bnQgaW50ZWdyaXR5IGNoZWNrIGZhaWxlZC4nIH0NCiAgICAgICAgJGFlcy5LZXkgPSBbYnl0ZVtdXSRrZXlbMC4uMzFdOyAkYWVzLklWID0gW0NvbnZlcnRdOjpGcm9tQmFzZTY0U3RyaW5nKCRwYXJ0c1sxXSkNCiAgICAgICAgJGNpcGhlciA9IFtDb252ZXJ0XTo6RnJvbUJhc2U2NFN0cmluZygkcGFydHNbMl0pDQogICAgICAgICRzdGF0ZSA9ICRzY3JpcHQ6VXRmOC5HZXRTdHJpbmcoJGFlcy5DcmVhdGVEZWNyeXB0b3IoKS5UcmFuc2Zvcm1GaW5hbEJsb2NrKCRjaXBoZXIsMCwkY2lwaGVyLkxlbmd0aCkpIHwgQ29udmVydEZyb20tSnNvbg0KICAgICAgICBBc3NlcnQtU3RhdGUgJHN0YXRlDQogICAgICAgIHJldHVybiAkc3RhdGUNCiAgICB9IGZpbmFsbHkgeyAkbWFjLkRpc3Bvc2UoKTsgJGFlcy5EaXNwb3NlKCkgfQ0KfQ0KZnVuY3Rpb24gUmVhZC1BY2NvdW50cyhbc3RyaW5nXSRUZXh0KSB7DQogICAgJGxpbmVzID0gJFRleHQuVHJpbUVuZCgiYHIiLCJgbiIpIC1zcGxpdCAnXHI/XG4nDQogICAgaWYgKCRsaW5lc1swXSAtbm90aW4gQCgnQ1NSQUNDT1VOVFMxJywnQ1NSQUNDT1VOVFMyJykpIHsgdGhyb3cgJ0ludmFsaWQgYWNjb3VudCBmb3JtYXQuJyB9DQogICAgJGFjY291bnRzID0gQHt9OyAkYWRtaW5zID0gMA0KICAgIGZvcmVhY2ggKCRsaW5lIGluICRsaW5lc1sxLi4oJGxpbmVzLkNvdW50LTEpXSkgew0KICAgICAgICAkcCA9ICRsaW5lIC1zcGxpdCAiYHQiLDAsJ1NpbXBsZU1hdGNoJw0KICAgICAgICBpZiAoJHAuQ291bnQgLW5lIDcgLW9yICRwWzBdIC1jbm90bWF0Y2ggJ15bYS16MC05XVthLXowLTkuXy1dezIsMzl9JCcgLW9yICRwWzJdIC1ub3RpbiBAKCdBZG1pbicsJ1VzZXInKSAtb3IgJHBbM10gLW5vdG1hdGNoICdeWzAxXSQnIC1vciAkcFs0XSAtY25vdG1hdGNoICdeWzAtOUEtRl17MzJ9JCcgLW9yICRwWzVdIC1jbm90bWF0Y2ggJ15bMC05QS1GXXs2NH0kJykgeyB0aHJvdyAnSW52YWxpZCBhY2NvdW50IGVudHJ5LicgfQ0KICAgICAgICBpZiAoJGFjY291bnRzLkNvbnRhaW5zS2V5KCRwWzBdKSkgeyB0aHJvdyAnRHVwbGljYXRlIGFjY291bnQgbmFtZS4nIH0NCiAgICAgICAgaWYgKCRsaW5lc1swXSAtZXEgJ0NTUkFDQ09VTlRTMicgLWFuZCAkcFs2XSAtbm90bWF0Y2ggJ14oXCp8W0EtWmEtejAtOV8sXSopJCcpIHsgdGhyb3cgJ0ludmFsaWQgcGVybWlzc2lvbnMuJyB9DQogICAgICAgICRhY2NvdW50c1skcFswXV0gPSAkcA0KICAgICAgICBpZiAoJHBbMl0gLWVxICdBZG1pbicgLWFuZCAkcFszXSAtZXEgJzEnKSB7ICRhZG1pbnMrKyB9DQogICAgfQ0KICAgIGlmICghJGFkbWlucykgeyB0aHJvdyAnS2VlcCBhdCBsZWFzdCBvbmUgZW5hYmxlZCBhZG1pbmlzdHJhdG9yLicgfQ0KICAgIHJldHVybiAkYWNjb3VudHMNCn0NCmZ1bmN0aW9uIEFzc2VydC1TdGF0ZShbb2JqZWN0XSRTdGF0ZSkgew0KICAgIGlmICgkU3RhdGUuU2NoZW1hIC1uZSAxIC1vciAkU3RhdGUuVmVyc2lvbiAtbm90bWF0Y2ggJ15cZCtcLlxkK1wuXGQrJCcgLW9yICRTdGF0ZS5SZXZpc2lvbiAtbm90bWF0Y2ggJ15bYS1mMC05XXszMn0kJykgeyB0aHJvdyAnSW52YWxpZCBzaGFyZWQgY29uZmlndXJhdGlvbi4nIH0NCiAgICBSZWFkLUFjY291bnRzICRTdGF0ZS5BY2NvdW50cyB8IE91dC1OdWxsDQogICAgaWYgKCRudWxsIC1uZSAkU3RhdGUuUmVsZWFzZSkgew0KICAgICAgICBpZiAoJFN0YXRlLlJlbGVhc2UuVmVyc2lvbiAtbmUgJFN0YXRlLlZlcnNpb24gLW9yICRTdGF0ZS5SZWxlYXNlLk1pbmltdW1WZXJzaW9uIC1uZSAkU3RhdGUuVmVyc2lvbiAtb3IgJFN0YXRlLlJlbGVhc2UuU0hBMjU2IC1ub3RtYXRjaCAnXltBLUZhLWYwLTldezY0fSQnIC1vciAkU3RhdGUuUmVsZWFzZS5QYWNrYWdlIC1uZSAoJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbS9JTG92ZVlvdUJldi9DU1ItVG9vbHMvbWFpbi9yZWxlYXNlcy9DU1JUb29scy0nICsgJFN0YXRlLlZlcnNpb24gKyAnLnppcCcpKSB7IHRocm93ICdJbnZhbGlkIHNoYXJlZCByZWxlYXNlIG1hbmlmZXN0LicgfQ0KICAgIH0NCn0NCmZ1bmN0aW9uIEludm9rZS1HaXRIdWIoW3N0cmluZ10kTWV0aG9kLFtzdHJpbmddJFBhdGgsJEJvZHkgPSAkbnVsbCxbc3dpdGNoXSRBbGxvd01pc3NpbmcpIHsNCiAgICAkaGVhZGVycyA9IEB7QWNjZXB0PSdhcHBsaWNhdGlvbi92bmQuZ2l0aHViK2pzb24nOydVc2VyLUFnZW50Jz0nQ1NSLVRvb2xzJzsnWC1HaXRIdWItQXBpLVZlcnNpb24nPScyMDI2LTAzLTEwJ30NCiAgICBpZiAoJHNjcmlwdDpUb2tlbikgeyAkaGVhZGVycy5BdXRob3JpemF0aW9uID0gJ0JlYXJlciAnICsgJHNjcmlwdDpUb2tlbiB9DQogICAgJGFyZ3MgPSBAe1VyaT0oJHNjcmlwdDpBcGkrJFBhdGgpO01ldGhvZD0kTWV0aG9kO0hlYWRlcnM9JGhlYWRlcnM7VGltZW91dFNlYz00NTtVc2VCYXNpY1BhcnNpbmc9JHRydWV9DQogICAgaWYgKCRudWxsIC1uZSAkQm9keSkgeyAkYXJncy5Cb2R5ID0gJHNjcmlwdDpVdGY4LkdldEJ5dGVzKCgkQm9keSB8IENvbnZlcnRUby1Kc29uIC1EZXB0aCAxMiAtQ29tcHJlc3MpKTsgJGFyZ3MuQ29udGVudFR5cGU9J2FwcGxpY2F0aW9uL2pzb24nIH0NCiAgICB0cnkgeyByZXR1cm4gKEludm9rZS1XZWJSZXF1ZXN0IEBhcmdzKS5Db250ZW50IHwgQ29udmVydEZyb20tSnNvbiB9DQogICAgY2F0Y2ggew0KICAgICAgICAkc3RhdHVzID0gMA0KICAgICAgICB0cnkgeyAkc3RhdHVzID0gW2ludF0kXy5FeGNlcHRpb24uUmVzcG9uc2UuU3RhdHVzQ29kZSB9IGNhdGNoIHt9DQogICAgICAgIGlmICgkQWxsb3dNaXNzaW5nIC1hbmQgJHN0YXR1cyAtZXEgNDA0KSB7IHJldHVybiAkbnVsbCB9DQogICAgICAgIGlmICgkc3RhdHVzIC1pbiBAKDQwOSw0MjIpKSB7IHRocm93ICdHaXRIdWIgY2hhbmdlZCBzaW5jZSB0aGlzIGVkaXQgc3RhcnRlZC4gUmVmcmVzaCBhY2NvdW50cyBhbmQgcmV0cnkuIE5vdGhpbmcgd2FzIG92ZXJ3cml0dGVuLicgfQ0KICAgICAgICBpZiAoJHN0YXR1cyAtaW4gQCg0MDEsNDAzLDQwNCkpIHsgdGhyb3cgJ0dpdEh1YiBhY2Nlc3Mgd2FzIGRlbmllZC4gQ29ubmVjdCBhIHRva2VuIHdpdGggQ29udGVudHMgcmVhZC93cml0ZSBwZXJtaXNzaW9uIGZvciBJTG92ZVlvdUJldi9DU1ItVG9vbHM7IGNoZWNrIGV4cGlyeSwgcmVwb3NpdG9yeSBhY2Nlc3MgYW5kIGJyYW5jaCBydWxlcy4nIH0NCiAgICAgICAgdGhyb3cgJ0Nhbm5vdCBjb21wbGV0ZSB0aGUgR2l0SHViIHJlcXVlc3QuIENoZWNrIGludGVybmV0IGFjY2VzcywgdGhlbiByZWZyZXNoIGJlZm9yZSByZXRyeWluZy4nDQogICAgfQ0KfQ0KZnVuY3Rpb24gUmVhZC1SZW1vdGUgew0KICAgICRmaWxlID0gSW52b2tlLUdpdEh1YiBHRVQgJy9jb250ZW50cy9jc3ItYWNjZXNzLmRhdD9yZWY9bWFpbicgJG51bGwgLUFsbG93TWlzc2luZw0KICAgIGlmICgkbnVsbCAtZXEgJGZpbGUpIHsgcmV0dXJuICRudWxsIH0NCiAgICBpZiAoJGZpbGUuZW5jb2RpbmcgLW5lICdiYXNlNjQnIC1vciAkZmlsZS5zaXplIC1ndCAyMDk3MTUyKSB7IHRocm93ICdJbnZhbGlkIHNoYXJlZCBmaWxlIHJlc3BvbnNlLicgfQ0KICAgIHJldHVybiBAe1N0YXRlPShVbnByb3RlY3QtU2hhcmVkICgkc2NyaXB0OlV0ZjguR2V0U3RyaW5nKFtDb252ZXJ0XTo6RnJvbUJhc2U2NFN0cmluZygkZmlsZS5jb250ZW50KSkpKTtTaGE9JGZpbGUuc2hhfQ0KfQ0KZnVuY3Rpb24gQ2FjaGUtU3RhdGUoJFN0YXRlKSB7DQogICAgQXNzZXJ0LVN0YXRlICRTdGF0ZQ0KICAgICRyZWxlYXNlID0gJycNCiAgICBpZiAoJG51bGwgLW5lICRTdGF0ZS5SZWxlYXNlKSB7ICRyZWxlYXNlID0gIlZlcnNpb249JCgkU3RhdGUuUmVsZWFzZS5WZXJzaW9uKWBuTWluaW11bVZlcnNpb249JCgkU3RhdGUuUmVsZWFzZS5NaW5pbXVtVmVyc2lvbilgblBhY2thZ2U9JCgkU3RhdGUuUmVsZWFzZS5QYWNrYWdlKWBuU0hBMjU2PSQoJFN0YXRlLlJlbGVhc2UuU0hBMjU2KSIgfQ0KICAgIFByb3RlY3QtTG9jYWwgKCJDU1JDTE9VRDFgbiIrJFN0YXRlLlZlcnNpb24rImBuIiskU3RhdGUuUmV2aXNpb24rImBuIitbQ29udmVydF06OlRvQmFzZTY0U3RyaW5nKCRzY3JpcHQ6VXRmOC5HZXRCeXRlcygkcmVsZWFzZSkpKyJgbiIrJFN0YXRlLkFjY291bnRzKSAoSm9pbi1QYXRoICREYXRhUm9vdCAnY2xvdWQtc3RhdGUuYmluJykNCiAgICBbSU8uRmlsZV06OldyaXRlQWxsVGV4dCgoSm9pbi1QYXRoICREYXRhUm9vdCAnY2xvdWQuaW5pdGlhbGl6ZWQnKSwnMScpDQp9DQpmdW5jdGlvbiBBc3NlcnQtQWN0b3IoJFJlcXVlc3QsJFN0YXRlKSB7DQogICAgJGFjY291bnRzID0gUmVhZC1BY2NvdW50cyAkU3RhdGUuQWNjb3VudHMNCiAgICBpZiAoISRhY2NvdW50cy5Db250YWluc0tleSgkUmVxdWVzdC5BY3RvcikpIHsgdGhyb3cgJ1RoaXMgYWRtaW5pc3RyYXRvciBubyBsb25nZXIgZXhpc3RzLiBTaWduIGluIGFnYWluLicgfQ0KICAgICRhY3RvciA9ICRhY2NvdW50c1skUmVxdWVzdC5BY3Rvcl0NCiAgICBpZiAoJGFjdG9yWzJdIC1uZSAnQWRtaW4nIC1vciAkYWN0b3JbM10gLW5lICcxJyAtb3IgJGFjdG9yWzVdIC1jbmUgJFJlcXVlc3QuQWN0b3JIYXNoKSB7IHRocm93ICdBZG1pbmlzdHJhdG9yIGFjY2VzcyBoYXMgY2hhbmdlZC4gU2lnbiBpbiBhZ2Fpbi4nIH0NCiAgICBpZiAoJFJlcXVlc3QuUmV2aXNpb24gLWNuZSAkU3RhdGUuUmV2aXNpb24pIHsgdGhyb3cgJ0FjY291bnRzIGNoYW5nZWQgb24gR2l0SHViLiBSZWZyZXNoIGFuZCBzZWxlY3QgdGhlIGFjY291bnQgYWdhaW4gYmVmb3JlIHNhdmluZy4nIH0NCn0NCmZ1bmN0aW9uIFNhdmUtUmVtb3RlKCRTdGF0ZSxbc3RyaW5nXSRTaGEsW3N0cmluZ10kTWVzc2FnZSkgew0KICAgICRib2R5ID0gQHttZXNzYWdlPSRNZXNzYWdlO2NvbnRlbnQ9W0NvbnZlcnRdOjpUb0Jhc2U2NFN0cmluZygkc2NyaXB0OlV0ZjguR2V0Qnl0ZXMoKFByb3RlY3QtU2hhcmVkICRTdGF0ZSkpKTticmFuY2g9J21haW4nfQ0KICAgIGlmICgkU2hhKSB7ICRib2R5LnNoYT0kU2hhIH0NCiAgICBJbnZva2UtR2l0SHViIFBVVCAnL2NvbnRlbnRzL2Nzci1hY2Nlc3MuZGF0JyAkYm9keSB8IE91dC1OdWxsDQogICAgdHJ5IHsgQ2FjaGUtU3RhdGUgJFN0YXRlIH0gY2F0Y2ggeyB0aHJvdyAiUHVibGlzaGVkIHRvIEdpdEh1YiwgYnV0IHRoZSBsb2NhbCBjYWNoZSBjb3VsZCBub3QgYmUgcmVmcmVzaGVkLiBSZWZyZXNoIGFjY291bnRzIGJlZm9yZSBlZGl0aW5nIGFnYWluLiIgfQ0KfQ0KZnVuY3Rpb24gUmVzdWx0KFtzdHJpbmddJFN0YXRlLFtzdHJpbmddJE1lc3NhZ2UpIHsNCiAgICBpZiAoJFJlc3VsdFBhdGgpIHsgW0lPLkZpbGVdOjpXcml0ZUFsbFRleHQoJFJlc3VsdFBhdGgsIltSZXN1bHRdYHJgblN0YXRlPSRTdGF0ZWByYG5NZXNzYWdlPSQoJE1lc3NhZ2UuUmVwbGFjZSgiYHIiLCcgJykuUmVwbGFjZSgiYG4iLCcgJykpYHJgbiIsJHNjcmlwdDpVdGY4KSB9DQp9DQpmdW5jdGlvbiBQdWJsaXNoLVJlbGVhc2UoJFJlcXVlc3QpIHsNCiAgICAjIFJlYWQgdGhlIGJyYW5jaCBCRUZPUkUgc3RhdGU7IGEgY29uY3VycmVudCBlZGl0IG1ha2VzIHRoZSBmaW5hbCBub24tZm9yY2UgcmVmIHVwZGF0ZSBmYWlsLg0KICAgICRoZWFkID0gSW52b2tlLUdpdEh1YiBHRVQgJy9naXQvcmVmL2hlYWRzL21haW4nDQogICAgJHJlbW90ZSA9IFJlYWQtUmVtb3RlDQogICAgaWYgKCRudWxsIC1lcSAkcmVtb3RlKSB7IHRocm93ICdQdWJsaXNoIHNoYXJlZCBhY2NvdW50cyBmaXJzdC4nIH0NCiAgICBBc3NlcnQtQWN0b3IgJFJlcXVlc3QgJHJlbW90ZS5TdGF0ZQ0KICAgICRzdHJlYW0gPSBbSU8uRmlsZV06Ok9wZW5SZWFkKCRQYWNrYWdlUGF0aCkNCiAgICAkaGFzaGVyID0gW1NlY3VyaXR5LkNyeXB0b2dyYXBoeS5TSEEyNTZdOjpDcmVhdGUoKQ0KICAgIHRyeSB7ICRoYXNoID0gW0JpdENvbnZlcnRlcl06OlRvU3RyaW5nKCRoYXNoZXIuQ29tcHV0ZUhhc2goJHN0cmVhbSkpLlJlcGxhY2UoJy0nLCcnKSB9IGZpbmFsbHkgeyAkc3RyZWFtLkRpc3Bvc2UoKTsgJGhhc2hlci5EaXNwb3NlKCkgfQ0KICAgICRyZWxlYXNlID0gW3BzY3VzdG9tb2JqZWN0XUB7VmVyc2lvbj0kUmVxdWVzdC5WZXJzaW9uO01pbmltdW1WZXJzaW9uPSRSZXF1ZXN0LlZlcnNpb247U0hBMjU2PSRoYXNoO1BhY2thZ2U9KCdodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vSUxvdmVZb3VCZXYvQ1NSLVRvb2xzL21haW4vcmVsZWFzZXMvQ1NSVG9vbHMtJyskUmVxdWVzdC5WZXJzaW9uKycuemlwJyl9DQogICAgaWYgKFt2ZXJzaW9uXSRyZWxlYXNlLlZlcnNpb24gLWxlIFt2ZXJzaW9uXSRyZW1vdGUuU3RhdGUuVmVyc2lvbikgeyB0aHJvdyAnVGhlIHVwZGF0ZSB2ZXJzaW9uIG11c3QgYmUgbmV3ZXIgdGhhbiB0aGUgdmVyc2lvbiBvbiBHaXRIdWIuJyB9DQogICAgJHN0YXRlID0gJHJlbW90ZS5TdGF0ZQ0KICAgICRzdGF0ZS5WZXJzaW9uID0gJHJlbGVhc2UuVmVyc2lvbjsgJHN0YXRlLlJlbGVhc2U9JHJlbGVhc2U7ICRzdGF0ZS5SZXZpc2lvbj1bZ3VpZF06Ok5ld0d1aWQoKS5Ub1N0cmluZygnTicpDQogICAgQXNzZXJ0LVN0YXRlICRzdGF0ZQ0KICAgICMgVGhlIGV4aXN0aW5nIHJlbGVhc2UgdmVyaWZpZXIgY2hlY2tzIGFyY2hpdmUgcGF0aHMsIGNoZWNrc3VtcywgY29udGVudHMgYW5kIEVYRSB2ZXJzaW9uLg0KICAgICRtYW5pZmVzdFBhdGggPSBKb2luLVBhdGggJERhdGFSb290ICgndmVyaWZ5LScgKyBbZ3VpZF06Ok5ld0d1aWQoKS5Ub1N0cmluZygnTicpICsgJy5pbmknKQ0KICAgICR2ZXJpZnlSZXN1bHQgPSAkbWFuaWZlc3RQYXRoICsgJy5yZXN1bHQnDQogICAgJG1hbmlmZXN0ID0gIltSZWxlYXNlXWByYG5WZXJzaW9uPSQoJHJlbGVhc2UuVmVyc2lvbilgcmBuTWluaW11bVZlcnNpb249JCgkcmVsZWFzZS5WZXJzaW9uKWByYG5QYWNrYWdlPSQoJHJlbGVhc2UuUGFja2FnZSlgcmBuU0hBMjU2PSQoJHJlbGVhc2UuU0hBMjU2KWByYG4iDQogICAgdHJ5IHsNCiAgICAgICAgW0lPLkZpbGVdOjpXcml0ZUFsbFRleHQoJG1hbmlmZXN0UGF0aCwkbWFuaWZlc3QsJHNjcmlwdDpVdGY4KQ0KICAgICAgICAkdmVyaWZpZXIgPSBKb2luLVBhdGggJEluc3RhbGxSb290ICdDU1IgUmVsZWFzZS5wczEnDQogICAgICAgICYgIiRQU0hPTUVccG93ZXJzaGVsbC5leGUiIC1Ob1Byb2ZpbGUgLU5vbkludGVyYWN0aXZlIC1FeGVjdXRpb25Qb2xpY3kgQnlwYXNzIC1GaWxlICR2ZXJpZmllciAtTW9kZSBWZXJpZnkgLVVwZGF0ZVBhY2thZ2UgLUluc3RhbGxSb290ICRJbnN0YWxsUm9vdCAtTWFuaWZlc3RQYXRoICRtYW5pZmVzdFBhdGggLVBhY2thZ2VQYXRoICRQYWNrYWdlUGF0aCAtUmVzdWx0UGF0aCAkdmVyaWZ5UmVzdWx0DQogICAgICAgIGlmICgkTEFTVEVYSVRDT0RFIC1uZSAwIC1vciBbSU8uRmlsZV06OlJlYWRBbGxUZXh0KCR2ZXJpZnlSZXN1bHQpIC1ub3RtYXRjaCAnU3RhdGU9VkVSSUZJRUQnKSB7IHRocm93ICdUaGUgc2VsZWN0ZWQgdXBkYXRlIHBhY2thZ2UgZmFpbGVkIHZlcmlmaWNhdGlvbi4nIH0NCiAgICB9IGZpbmFsbHkgew0KICAgICAgICBmb3JlYWNoICgkcGF0aCBpbiBAKCRtYW5pZmVzdFBhdGgsJHZlcmlmeVJlc3VsdCkpIHsgaWYgKFtJTy5GaWxlXTo6RXhpc3RzKCRwYXRoKSkgeyBbSU8uRmlsZV06OkRlbGV0ZSgkcGF0aCkgfSB9DQogICAgfQ0KICAgIGlmICgoR2V0LUl0ZW0gLUxpdGVyYWxQYXRoICRQYWNrYWdlUGF0aCkuTGVuZ3RoIC1ndCA0MDAwMDAwMCkgeyB0aHJvdyAnVXBkYXRlIHBhY2thZ2UgZXhjZWVkcyB0aGUgNDAgTUIgcHVibGlzaGVyIGxpbWl0LicgfQ0KICAgICRlbnRyaWVzID0gQCgpDQogICAgJGZpbGVzID0gQHsNCiAgICAgICAgJ2Nzci1hY2Nlc3MuZGF0Jz0kc2NyaXB0OlV0ZjguR2V0Qnl0ZXMoKFByb3RlY3QtU2hhcmVkICRzdGF0ZSkpOw0KICAgICAgICAncmVsZWFzZS5pbmknPSRzY3JpcHQ6VXRmOC5HZXRCeXRlcygkbWFuaWZlc3QpOw0KICAgICAgICAndmVyc2lvbi50eHQnPSRzY3JpcHQ6VXRmOC5HZXRCeXRlcygkcmVsZWFzZS5WZXJzaW9uKTsNCiAgICAgICAgJ3JlbGVhc2Utbm90ZXMudHh0Jz0kc2NyaXB0OlV0ZjguR2V0Qnl0ZXMoJFJlcXVlc3QuTm90ZXMpDQogICAgfQ0KICAgICRmaWxlc1sncmVsZWFzZXMvQ1NSVG9vbHMtJyskcmVsZWFzZS5WZXJzaW9uKycuemlwJ109W0lPLkZpbGVdOjpSZWFkQWxsQnl0ZXMoJFBhY2thZ2VQYXRoKQ0KICAgIGZvcmVhY2ggKCRwYXRoIGluICRmaWxlcy5LZXlzKSB7DQogICAgICAgICRibG9iID0gSW52b2tlLUdpdEh1YiBQT1NUICcvZ2l0L2Jsb2JzJyBAe2VuY29kaW5nPSdiYXNlNjQnO2NvbnRlbnQ9W0NvbnZlcnRdOjpUb0Jhc2U2NFN0cmluZygkZmlsZXNbJHBhdGhdKX0NCiAgICAgICAgJGVudHJpZXMgKz0gQHtwYXRoPSRwYXRoO21vZGU9JzEwMDY0NCc7dHlwZT0nYmxvYic7c2hhPSRibG9iLnNoYX0NCiAgICB9DQogICAgJGNvbW1pdCA9IEludm9rZS1HaXRIdWIgR0VUICgnL2dpdC9jb21taXRzLycrJGhlYWQub2JqZWN0LnNoYSkNCiAgICAkdHJlZSA9IEludm9rZS1HaXRIdWIgUE9TVCAnL2dpdC90cmVlcycgQHtiYXNlX3RyZWU9JGNvbW1pdC50cmVlLnNoYTt0cmVlPSRlbnRyaWVzfQ0KICAgICRuZXdDb21taXQgPSBJbnZva2UtR2l0SHViIFBPU1QgJy9naXQvY29tbWl0cycgQHttZXNzYWdlPSgnUmVxdWlyZWQgQ1NSIFRvb2xzIHVwZGF0ZSAnKyRyZWxlYXNlLlZlcnNpb24pO3RyZWU9JHRyZWUuc2hhO3BhcmVudHM9QCgkaGVhZC5vYmplY3Quc2hhKX0NCiAgICBJbnZva2UtR2l0SHViIFBBVENIICcvZ2l0L3JlZnMvaGVhZHMvbWFpbicgQHtzaGE9JG5ld0NvbW1pdC5zaGE7Zm9yY2U9JGZhbHNlfSB8IE91dC1OdWxsDQogICAgdHJ5IHsgQ2FjaGUtU3RhdGUgJHN0YXRlIH0gY2F0Y2ggeyB0aHJvdyAiVGhlIHVwZGF0ZSB3YXMgcHVibGlzaGVkLCBidXQgdGhlIGxvY2FsIGNhY2hlIGNvdWxkIG5vdCBiZSByZWZyZXNoZWQuIFJlc3RhcnQgYW5kIGNoZWNrIGZvciB1cGRhdGVzLiIgfQ0KfQ0KZnVuY3Rpb24gUHVibGlzaC1BY2NvdW50cygkcmVxdWVzdCkgew0KICAgICAgICAgICAgJHJlbW90ZSA9IFJlYWQtUmVtb3RlDQogICAgICAgICAgICBSZWFkLUFjY291bnRzICRyZXF1ZXN0LkFjY291bnRzIHwgT3V0LU51bGwNCiAgICAgICAgICAgIGlmICgkbnVsbCAtZXEgJHJlbW90ZSkgew0KICAgICAgICAgICAgICAgIGlmICgkcmVxdWVzdC5SZXZpc2lvbiAtbmUgJycgLW9yICEkcmVxdWVzdC5Cb290c3RyYXApIHsgdGhyb3cgJ1NoYXJlZCBhY2NvdW50cyBhcmUgbWlzc2luZy4gUmVzdG9yZSB0aGVtIHJhdGhlciB0aGFuIHJlY3JlYXRpbmcgdGhlbS4nIH0NCiAgICAgICAgICAgICAgICAkc3RhdGUgPSBbcHNjdXN0b21vYmplY3RdQHtTY2hlbWE9MTtWZXJzaW9uPSRyZXF1ZXN0LlZlcnNpb247UmV2aXNpb249Jyc7QWNjb3VudHM9JHJlcXVlc3QuQWNjb3VudHM7UmVsZWFzZT0kbnVsbH0NCiAgICAgICAgICAgICAgICAjIEJvb3RzdHJhcCBtdXN0IG5vdCBsb3dlciBhbiBhbHJlYWR5IHB1Ymxpc2hlZCBzb2Z0d2FyZSByZXF1aXJlbWVudC4NCiAgICAgICAgICAgICAgICAkZXhpc3RpbmcgPSBJbnZva2UtR2l0SHViIEdFVCAnL2NvbnRlbnRzL3JlbGVhc2UuaW5pP3JlZj1tYWluJyAkbnVsbCAtQWxsb3dNaXNzaW5nDQogICAgICAgICAgICAgICAgaWYgKCRudWxsIC1uZSAkZXhpc3RpbmcpIHsNCiAgICAgICAgICAgICAgICAgICAgJHRleHQgPSAkc2NyaXB0OlV0ZjguR2V0U3RyaW5nKFtDb252ZXJ0XTo6RnJvbUJhc2U2NFN0cmluZygkZXhpc3RpbmcuY29udGVudCkpDQogICAgICAgICAgICAgICAgICAgICRmaWVsZHMgPSBAe307IGZvcmVhY2ggKCRsaW5lIGluICgkdGV4dCAtc3BsaXQgJ1xyP1xuJykpIHsgaWYgKCRsaW5lIC1tYXRjaCAnXihWZXJzaW9ufE1pbmltdW1WZXJzaW9ufFBhY2thZ2V8U0hBMjU2KT0oLiopJCcpIHsgJGZpZWxkc1skbWF0Y2hlc1sxXV09JG1hdGNoZXNbMl0gfSB9DQogICAgICAgICAgICAgICAgICAgICRzdGF0ZS5WZXJzaW9uPSRmaWVsZHMuVmVyc2lvbjsgJGZpZWxkcy5NaW5pbXVtVmVyc2lvbj0kZmllbGRzLlZlcnNpb247ICRzdGF0ZS5SZWxlYXNlPVtwc2N1c3RvbW9iamVjdF0kZmllbGRzDQogICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgICAgICRzaGEgPSAnJw0KICAgICAgICAgICAgfSBlbHNlIHsNCiAgICAgICAgICAgICAgICBBc3NlcnQtQWN0b3IgJHJlcXVlc3QgJHJlbW90ZS5TdGF0ZQ0KICAgICAgICAgICAgICAgICRzdGF0ZT0kcmVtb3RlLlN0YXRlOyAkc2hhPSRyZW1vdGUuU2hhDQogICAgICAgICAgICAgICAgJHN0YXRlLkFjY291bnRzPSRyZXF1ZXN0LkFjY291bnRzDQogICAgICAgICAgICB9DQogICAgICAgICAgICAkc3RhdGUuUmV2aXNpb249W2d1aWRdOjpOZXdHdWlkKCkuVG9TdHJpbmcoJ04nKQ0KICAgICAgICAgICAgQXNzZXJ0LVN0YXRlICRzdGF0ZQ0KICAgICAgICAgICAgU2F2ZS1SZW1vdGUgJHN0YXRlICRzaGEgJ1VwZGF0ZSBDU1IgYWNjb3VudCBhY2Nlc3MnDQp9DQppZiAoJE1vZGUgLWVxICdMaWJyYXJ5JykgeyByZXR1cm4gfQ0KdHJ5IHsNCiAgICBbTmV0LlNlcnZpY2VQb2ludE1hbmFnZXJdOjpTZWN1cml0eVByb3RvY29sID0gW05ldC5TZWN1cml0eVByb3RvY29sVHlwZV06OlRsczEyDQogICAgaWYgKCEkRGF0YVJvb3QpIHsgdGhyb3cgJ01pc3NpbmcgYWNjb3VudCBzdG9yYWdlIGRpcmVjdG9yeS4nIH0NCiAgICBbSU8uRGlyZWN0b3J5XTo6Q3JlYXRlRGlyZWN0b3J5KCREYXRhUm9vdCkgfCBPdXQtTnVsbA0KICAgICMgUHJldmVudCBhIHRpbWVyIHN5bmMgYW5kIGFuIGFjY291bnQgcHVibGlzaCBvbiB0aGlzIGNvbXB1dGVyIGZyb20gcmFjaW5nIHRoZSBjYWNoZS4NCiAgICAkbG9jayA9IFtJTy5GaWxlXTo6T3BlbigoSm9pbi1QYXRoICREYXRhUm9vdCAnY2xvdWQubG9jaycpLFtJTy5GaWxlTW9kZV06Ok9wZW5PckNyZWF0ZSxbSU8uRmlsZUFjY2Vzc106OlJlYWRXcml0ZSxbSU8uRmlsZVNoYXJlXTo6Tm9uZSkNCiAgICBpZiAoJE1vZGUgLWVxICdDb25uZWN0Jykgew0KICAgICAgICAkc2NyaXB0OlRva2VuID0gKFVucHJvdGVjdC1Mb2NhbCAkSW5wdXRQYXRoKS5UcmltKCkNCiAgICAgICAgaWYgKCRzY3JpcHQ6VG9rZW4uTGVuZ3RoIC1sdCAyMCAtb3IgJHNjcmlwdDpUb2tlbiAtbWF0Y2ggJ1xzJykgeyB0aHJvdyAnRW50ZXIgYSB2YWxpZCBHaXRIdWIgdG9rZW4uJyB9DQogICAgICAgIEludm9rZS1HaXRIdWIgR0VUICcnIHwgT3V0LU51bGwNCiAgICAgICAgUHJvdGVjdC1Mb2NhbCAkc2NyaXB0OlRva2VuIChKb2luLVBhdGggJERhdGFSb290ICdnaXRodWItdG9rZW4uYmluJykNCiAgICAgICAgUmVzdWx0ICdDT05ORUNURUQnICdHaXRIdWIgY29ubmVjdGVkIG9uIHRoaXMgV2luZG93cyBsb2dpbi4gUHVibGlzaGluZyB3aWxsIHZlcmlmeSByZXBvc2l0b3J5IHdyaXRlIGFjY2Vzcy4nDQogICAgfSBlbHNlaWYgKCRNb2RlIC1lcSAnRGlzY29ubmVjdCcpIHsNCiAgICAgICAgZm9yZWFjaCAoJG5hbWUgaW4gQCgnZ2l0aHViLXRva2VuLmJpbicsJ2dpdGh1Yi10b2tlbi5iaW4ucHJldmlvdXMnKSkgew0KICAgICAgICAgICAgJHBhdGggPSBKb2luLVBhdGggJERhdGFSb290ICRuYW1lDQogICAgICAgICAgICBpZiAoW0lPLkZpbGVdOjpFeGlzdHMoJHBhdGgpKSB7IFtJTy5GaWxlXTo6RGVsZXRlKCRwYXRoKSB9DQogICAgICAgIH0NCiAgICAgICAgUmVzdWx0ICdESVNDT05ORUNURUQnICdHaXRIdWIgcHVibGlzaGluZyBkaXNjb25uZWN0ZWQgb24gdGhpcyBXaW5kb3dzIGxvZ2luLicNCiAgICB9IGVsc2VpZiAoJE1vZGUgLWVxICdTeW5jJykgew0KICAgICAgICAjIFB1YmxpYyByYXcgcmVhZCBhdm9pZHMgdXNpbmcgb3IgZGlzdHJpYnV0aW5nIGFkbWluaXN0cmF0b3IgdG9rZW5zIHRvIHJlZ3VsYXIgdXNlcnMuDQogICAgICAgIHRyeSB7DQogICAgICAgICAgICAkcmVzcG9uc2UgPSBJbnZva2UtV2ViUmVxdWVzdCAtVXJpICgnaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0lMb3ZlWW91QmV2L0NTUi1Ub29scy9tYWluL2Nzci1hY2Nlc3MuZGF0P25vY2FjaGU9JytbZ3VpZF06Ok5ld0d1aWQoKS5Ub1N0cmluZygnTicpKSAtVXNlQmFzaWNQYXJzaW5nIC1UaW1lb3V0U2VjIDIwIC1IZWFkZXJzIEB7J0NhY2hlLUNvbnRyb2wnPSduby1jYWNoZSd9DQogICAgICAgICAgICAkY29udGVudCA9IGlmICgkcmVzcG9uc2UuQ29udGVudCAtaXMgW2J5dGVbXV0pIHsgJHNjcmlwdDpVdGY4LkdldFN0cmluZygkcmVzcG9uc2UuQ29udGVudCkgfSBlbHNlIHsgW3N0cmluZ10kcmVzcG9uc2UuQ29udGVudCB9DQogICAgICAgICAgICAkc3RhdGUgPSBVbnByb3RlY3QtU2hhcmVkICRjb250ZW50DQogICAgICAgICAgICBDYWNoZS1TdGF0ZSAkc3RhdGUNCiAgICAgICAgICAgIFJlc3VsdCAnU1lOQ0VEJyAnU2hhcmVkIGFjY291bnRzIHJlZnJlc2hlZC4nDQogICAgICAgIH0gY2F0Y2ggew0KICAgICAgICAgICAgJG1pc3NpbmcgPSAkZmFsc2UNCiAgICAgICAgICAgIHRyeSB7ICRtaXNzaW5nID0gW2ludF0kXy5FeGNlcHRpb24uUmVzcG9uc2UuU3RhdHVzQ29kZSAtZXEgNDA0IH0gY2F0Y2gge30NCiAgICAgICAgICAgIGlmICgkbWlzc2luZyAtYW5kICEoVGVzdC1QYXRoIC1MaXRlcmFsUGF0aCAoSm9pbi1QYXRoICREYXRhUm9vdCAnY2xvdWQuaW5pdGlhbGl6ZWQnKSkpIHsgUmVzdWx0ICdNSVNTSU5HJyAnU2hhcmVkIGFjY291bnRzIGhhdmUgbm90IGJlZW4gcHVibGlzaGVkIHlldC4nIH0NCiAgICAgICAgICAgIGVsc2UgeyB0aHJvdyAnQ2Fubm90IHZlcmlmeSBzaGFyZWQgYWNjb3VudHMuIENvbm5lY3QgdG8gdGhlIGludGVybmV0IGFuZCByZXRyeTsgYXV0b21hdGlvbiByZW1haW5zIGxvY2tlZC4nIH0NCiAgICAgICAgfQ0KICAgIH0gZWxzZSB7DQogICAgICAgICRzY3JpcHQ6VG9rZW4gPSBVbnByb3RlY3QtTG9jYWwgKEpvaW4tUGF0aCAkRGF0YVJvb3QgJ2dpdGh1Yi10b2tlbi5iaW4nKQ0KICAgICAgICAkcmVxdWVzdCA9IFVucHJvdGVjdC1Mb2NhbCAkSW5wdXRQYXRoIHwgQ29udmVydEZyb20tSnNvbg0KICAgICAgICBpZiAoJE1vZGUgLWVxICdSZWxlYXNlJykgew0KICAgICAgICAgICAgUHVibGlzaC1SZWxlYXNlICRyZXF1ZXN0DQogICAgICAgICAgICBSZXN1bHQgJ1BVQkxJU0hFRCcgJ1JlcXVpcmVkIHVwZGF0ZSBwdWJsaXNoZWQuIENsaWVudHMgd2lsbCBsb2NrIGF0IHRoZWlyIG5leHQgY2hlY2suJw0KICAgICAgICB9IGVsc2Ugew0KICAgICAgICAgICAgUHVibGlzaC1BY2NvdW50cyAkcmVxdWVzdA0KICAgICAgICAgICAgUmVzdWx0ICdTQVZFRCcgJ1NoYXJlZCBhY2NvdW50cyBwdWJsaXNoZWQuIFNvZnR3YXJlIHZlcnNpb24gdW5jaGFuZ2VkLicNCiAgICAgICAgfQ0KICAgIH0NCn0gY2F0Y2ggeyBSZXN1bHQgJ0ZBSUxFRCcgJF8uRXhjZXB0aW9uLk1lc3NhZ2U7IGV4aXQgMSB9DQpmaW5hbGx5IHsgaWYgKEdldC1WYXJpYWJsZSBsb2NrIC1FcnJvckFjdGlvbiBTaWxlbnRseUNvbnRpbnVlKSB7IGlmICgkbG9jaykgeyAkbG9jay5EaXNwb3NlKCkgfSB9OyAkc2NyaXB0OlRva2VuPScnIH0NCg=='
if ($Mode -like 'Cloud*') {
    if (Get-Variable CSRCloudEmbedded -ErrorAction SilentlyContinue) {
        $cloudCode = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($CSRCloudEmbedded)).TrimStart([char]0xFEFF)
    } else { $cloudCode = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'CSR Cloud.ps1')) }
    & ([scriptblock]::Create($cloudCode)) -Mode $Mode.Substring(5) -DataRoot $DataRoot -InputPath $InputPath -ResultPath $ResultPath -InstallRoot $InstallRoot -PackagePath $PackagePath
    exit
}
$ErrorActionPreference = 'Stop' 
Set-StrictMode -Version Latest
if (!$InstallRoot) { $InstallRoot = Split-Path -Parent $MyInvocation.MyCommand.Path }
$script:workspaceRoot = [IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')
if (!$CompilerPath) { $CompilerPath = Join-Path $script:workspaceRoot 'Tools\Ahk2Exe.exe' }
if (!$BasePath) { $BasePath = Join-Path $script:workspaceRoot 'Tools\AutoHotkeySC.bin' }
$sourceFiles = @('CSR TOOL 4.3.AHK','CSR UI.ahk','CSR Access.ahk','CSR Cloud.ahk','CSR Updates.ahk','CSR Substitutes.ahk','CSR Inventory.ahk','CSR FFV.ahk','CSR Picking Context.ahk','CSR Weights.ahk','CSR Extended Shelf Life.ahk','CSR Updated Fill Rate.ahk','CSR DN Checker.ahk','CSR Order Checker.ahk','CSR Priority Fill Rate.ahk')
$requiredFiles = @('CSR Tools.exe','CSR Release.ps1','NSNLIST.txt','CSR Tools - User Guide.txt','NSN_Substitute_Lookup/Substitutions.tsv','AverageWeights.tsv','ExtendedShelfLife.tsv')
function Get-CSRFileSHA256([string]$LiteralPath) {
    $stream = [IO.File]::OpenRead($LiteralPath)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try {
        return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-','')
    } finally {
        $algorithm.Dispose()
        $stream.Dispose()
    }
}
function Initialize-CSRZipRuntime {
    # Load the .NET ZIP runtime without depending on the PowerShell Archive module.
    [Reflection.Assembly]::Load('System.IO.Compression.FileSystem, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') | Out-Null
}
function Resolve-SafeChild([string]$Parent,[string]$Relative) {
    if ([IO.Path]::IsPathRooted($Relative) -or $Relative -match '(^|[\\/])\.\.([\\/]|$)|:') { throw 'Unsafe update path.' }
    $target = [IO.Path]::GetFullPath((Join-Path $Parent $Relative))
    if (!$target.StartsWith($Parent.TrimEnd('\') + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Update path escaped its directory.' }
    return $target
}
function Invoke-CheckedGit([string[]]$GitArguments) {
    $safeDirectory = [IO.Path]::GetFullPath($RepositoryPath).Replace("\","/")
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        $output = & git -c ("safe.directory=" + $safeDirectory) -C $RepositoryPath @GitArguments 2>&1
        $gitExit = $LASTEXITCODE
    } finally { $ErrorActionPreference = $previousPreference }
    if ($gitExit -ne 0) { throw ('Git failed: ' + ($output -join [Environment]::NewLine)) }
    return ($output -join "`n")
}
function Resolve-PublisherRepository([string]$Selected,[string]$SourceRoot) {
    $candidates = [Collections.Generic.List[string]]::new()
    if ($Selected) {
        $candidates.Add($Selected)
        $candidates.Add((Join-Path $Selected 'Update Github'))
        $candidates.Add((Join-Path $Selected '_Archive_2026-10-07\Update Github'))
    }
    $candidates.Add((Join-Path $SourceRoot 'Update Github'))
    $candidates.Add((Join-Path $SourceRoot '_Archive_2026-10-07\Update Github'))
    $sourceCanonical = [IO.Path]::GetFullPath($SourceRoot).TrimEnd('\')
    foreach ($candidate in $candidates) {
        $canonical = [IO.Path]::GetFullPath($candidate).TrimEnd('\')
        # Never publish from the live source workspace. Use its separate release checkout.
        if ($canonical -eq $sourceCanonical) { continue }
        if (!(Test-Path -LiteralPath (Join-Path $canonical '.git'))) { continue }
        $previousPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            $origin = & git -c ('safe.directory=' + $canonical.Replace('\','/')) -C $canonical remote get-url origin 2>&1
            $originExit = $LASTEXITCODE
        } finally { $ErrorActionPreference = $previousPreference }
        if ($originExit -eq 0 -and ($origin -join "`n").Trim() -match '^(https://github\.com/ILoveYouBev/CSR-Tools(?:\.git)?|git@github\.com:ILoveYouBev/CSR-Tools(?:\.git)?)$') { return $canonical }
    }
    throw 'No Git checkout was found. In Admin > Publisher setup, choose the folder containing .git for ILoveYouBev/CSR-Tools.'
}
function Write-Result([string]$State,[string]$Message) {
    if ($ResultPath) {
        $messageValue = $Message.Replace("`r",' ').Replace("`n",' ')
        [IO.File]::WriteAllText($ResultPath,"[Result]`r`nState=$State`r`nMessage=$messageValue`r`n",[Text.UTF8Encoding]::new($false))
    }
}
try {
    if ($Mode -in @('Publish','Prepare','Check')) {
        if ($NextVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'Release version must use major.minor.patch.' }
        $mainPath = Join-Path $script:workspaceRoot 'CSR TOOL 4.3.AHK'
        $main = [IO.File]::ReadAllText($mainPath)
        $match = [regex]::Match($main,'(?m)^global version := "(\d+\.\d+\.\d+)"')
        if (!$match.Success) { throw 'The local script version could not be read.' }
        $current = [version]$match.Groups[1].Value
        if ([version]$NextVersion -lt $current -or ($Mode -eq 'Publish' -and [version]$NextVersion -eq $current)) { throw 'The next published version must be newer than the installed version.' }
        $notes = if ($NotesPath) { [IO.File]::ReadAllText($NotesPath).Trim() } else { '' }
        if ($notes.Length -lt 5 -or $notes.Length -gt 4000) { throw 'Enter release notes of 5-4000 characters.' }
        if ($Mode -eq 'Publish') { throw 'Use Admin > Build next update ZIP, then Publish update ZIP. Account and software versions publish together through GitHub.' }
        if ($Mode -in @('Publish','Check')) {
            $RepositoryPath = Resolve-PublisherRepository $RepositoryPath $script:workspaceRoot
            if ((Invoke-CheckedGit -GitArguments @('status','--porcelain')).Trim()) { throw 'The publishing checkout has uncommitted changes. Resolve them before publishing.' }
            if ((Invoke-CheckedGit -GitArguments @('branch','--show-current')).Trim() -ne 'main') { throw 'The publishing checkout must be on main.' }
            $remote = (Invoke-CheckedGit -GitArguments @('remote','get-url','origin')).Trim()
            if ($remote -notmatch '^(https://github\.com/ILoveYouBev/CSR-Tools(?:\.git)?|git@github\.com:ILoveYouBev/CSR-Tools(?:\.git)?)$') { throw 'The publishing checkout has an unexpected origin.' }
            if ($Mode -eq 'Publish') {
                Invoke-CheckedGit -GitArguments @('fetch','origin','main') | Out-Null
                Invoke-CheckedGit -GitArguments @('merge','--ff-only','origin/main') | Out-Null
            }
            $remoteManifest = Join-Path $RepositoryPath 'release.ini'
            if (Test-Path -LiteralPath $remoteManifest) {
                $remoteText = [IO.File]::ReadAllText($remoteManifest)
                $remoteMatch = [regex]::Match($remoteText,'(?m)^Version=(\d+\.\d+\.\d+)\r?$')
                if (!$remoteMatch.Success -or [version]$NextVersion -le [version]$remoteMatch.Groups[1].Value) { throw 'Another release already uses this version. Update your client before publishing.' }
            }
        }
        if (!(Test-Path -LiteralPath $CompilerPath -PathType Leaf) -or !(Test-Path -LiteralPath $BasePath -PathType Leaf)) { throw 'Configure Ahk2Exe and its AutoHotkey v1 base in Publisher setup.' }
        if ($Mode -eq 'Check') {
            Write-Result 'READY' ('Publisher ready. Git checkout: ' + $RepositoryPath + '. Next version: ' + $NextVersion)
            exit 0
        }
        $buildRoot = Join-Path $script:workspaceRoot ('_Releases\' + $NextVersion + '-' + [guid]::NewGuid().ToString('N'))
        if (Test-Path -LiteralPath $buildRoot) { throw 'This release directory already exists. Review it and choose another version or move it aside before retrying.' }
        $packageRoot = Join-Path $buildRoot 'package'
        $compileRoot = Join-Path $buildRoot 'source'
        New-Item -ItemType Directory -Path $compileRoot -Force | Out-Null
        if (!(Test-Path -LiteralPath $CompilerPath -PathType Leaf) -or !(Test-Path -LiteralPath $BasePath -PathType Leaf)) { throw 'Configure Ahk2Exe and its AutoHotkey v1 base in Publisher setup.' }
        foreach ($relative in $sourceFiles) { Copy-Item -LiteralPath (Resolve-SafeChild $script:workspaceRoot $relative) -Destination (Join-Path $compileRoot $relative) }
        $catalogStage = Join-Path $compileRoot 'NSN_Substitute_Lookup'
        New-Item -ItemType Directory -Path $catalogStage -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $script:workspaceRoot 'NSN_Substitute_Lookup\Substitutions.tsv') -Destination $catalogStage
        New-Item -ItemType Directory -Path $packageRoot -Force | Out-Null
        foreach ($relative in @('CSR Release.ps1','NSNLIST.txt','CSR Tools - User Guide.txt','NSN_Substitute_Lookup/Substitutions.tsv','AverageWeights.tsv','ExtendedShelfLife.tsv')) {
            $source = Resolve-SafeChild $script:workspaceRoot $relative
            if (!(Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing release dependency: $relative" }
            $dependencyTarget = Join-Path $packageRoot $relative
            New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($dependencyTarget)) -Force | Out-Null
            Copy-Item -LiteralPath $source -Destination $dependencyTarget
        }
        # Embed the cloud helper in the existing release helper so older package allowlists still accept it.
        $releaseHelper = Join-Path $packageRoot 'CSR Release.ps1'
        $cloudPayload = [Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $script:workspaceRoot 'CSR Cloud.ps1')))
        $releaseCode = [regex]::Replace([IO.File]::ReadAllText($releaseHelper), '(?m)^(?:# CSR_CLOUD_EMBED|\$CSRCloudEmbedded = ''[A-Za-z0-9+/=]+'')\r?$', { param($marker) '$CSRCloudEmbedded = ' + "'" + $cloudPayload + "'" })
        [IO.File]::WriteAllText($releaseHelper,$releaseCode,[Text.UTF8Encoding]::new($true))
        $helperTokens = $null; $helperErrors = $null
        [Management.Automation.Language.Parser]::ParseFile($releaseHelper,[ref]$helperTokens,[ref]$helperErrors) | Out-Null
        if ($helperErrors.Count) { throw 'Packaged update helper failed syntax validation.' }
        foreach ($folder in @('Image Search','Hotstrings')) {
            if ($UpdatePackage -and $folder -eq 'Image Search') { continue }
            $target = Join-Path $packageRoot $folder
            New-Item -ItemType Directory -Path $target -Force | Out-Null
            $pattern = if ($folder -eq 'Image Search') { '*.png' } else { '*.txt' }
            Get-ChildItem -LiteralPath (Join-Path $script:workspaceRoot $folder) -File -Filter $pattern | ForEach-Object {
                if ($_.Name -ne '-checknis.txt') { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $target $_.Name) }
            }
        }
        $packagedMain = Join-Path $compileRoot 'CSR TOOL 4.3.AHK'
                $compiledSource = [regex]::Replace($main,'(?m)^global version := "\d+\.\d+\.\d+"',('global version := "' + $NextVersion + '"'))
        $compiledSource = [regex]::Replace($compiledSource,'(?m)^;@Ahk2Exe-Set(?:Version|ProductVersion) .*$', {param($m) ($m.Value.Split(' ')[0] + ' ' + $NextVersion)})
        [IO.File]::WriteAllText($packagedMain,$compiledSource,[Text.UTF8Encoding]::new($true))
        # Includes resolve against the staging source directory. No personal scripts are shipped.
        $outExe = Join-Path $packageRoot 'CSR Tools.exe'
        $arguments = '/in "' + $packagedMain + '" /out "' + $outExe + '" /base "' + $BasePath + '" /compress 0 /silent verbose'
        $compile = Start-Process -FilePath $CompilerPath -ArgumentList $arguments -WorkingDirectory $compileRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $buildRoot 'compiler.log') -RedirectStandardError (Join-Path $buildRoot 'compiler-errors.log')
        $compileHandle = $compile.Handle
        if (!$compile.WaitForExit(60000)) { throw 'Compilation timed out. Nothing was published.' }
        $compile.Refresh()
        if ($compile.ExitCode -ne 0 -or !(Test-Path -LiteralPath $outExe)) { throw ('Compilation failed. Read ' + (Join-Path $buildRoot 'compiler.log')) }
        $check = Start-Process -FilePath $outExe -ArgumentList '--verify-build' -WindowStyle Hidden -PassThru
        $checkHandle = $check.Handle
        if (!$check.WaitForExit(30000)) { throw 'Compiled application verification timed out.' }
        $check.Refresh()
        if ($check.ExitCode -ne 0 -or !(Test-Path -LiteralPath ($outExe + '.verified'))) { throw 'Compiled application verification failed.' }
        Remove-Item -LiteralPath ($outExe + '.verified')
        $files = @(Get-ChildItem -LiteralPath $packageRoot -Recurse -File | ForEach-Object {
            @{path=$_.FullName.Substring($packageRoot.Length+1).Replace('\','/');sha256=(Get-CSRFileSHA256 -LiteralPath $_.FullName)}
        })
        @{version=$NextVersion;files=$files} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $packageRoot 'package-manifest.json') -Encoding UTF8
        $zipName = 'CSRTools-' + $NextVersion + '.zip'
        $zipPath = Join-Path $buildRoot $zipName
        Initialize-CSRZipRuntime
        [IO.Compression.ZipFile]::CreateFromDirectory($packageRoot, $zipPath, [IO.Compression.CompressionLevel]::Optimal, $false)
        $hash = (Get-CSRFileSHA256 -LiteralPath $zipPath)
        $manifest = "[Release]`r`nVersion=$NextVersion`r`nMinimumVersion=$NextVersion`r`nPackage=https://raw.githubusercontent.com/ILoveYouBev/CSR-Tools/main/releases/$zipName`r`nSHA256=$hash`r`n"
        [IO.File]::WriteAllText((Join-Path $buildRoot 'release.ini'),$manifest,[Text.UTF8Encoding]::new($false))
        [IO.File]::WriteAllText((Join-Path $buildRoot 'release-notes.txt'),$notes,[Text.UTF8Encoding]::new($false))
        $distribution = Join-Path $script:workspaceRoot $(if ($UpdatePackage) { 'Distribution\Updates' } else { 'Distribution' })
        New-Item -ItemType Directory -Path $distribution -Force | Out-Null
        Copy-Item -LiteralPath $zipPath -Destination (Join-Path $distribution $zipName) -Force
        if ($Mode -eq 'Prepare') {
            Write-Result 'PREPARED' "Prepared $NextVersion. Nothing was uploaded or changed in the running installation."
        } else {
            New-Item -ItemType Directory -Path (Join-Path $RepositoryPath 'releases') -Force | Out-Null
            Copy-Item -LiteralPath $zipPath -Destination (Join-Path $RepositoryPath ('releases\' + $zipName))
            Copy-Item -LiteralPath (Join-Path $buildRoot 'release.ini') -Destination $remoteManifest
            Copy-Item -LiteralPath (Join-Path $buildRoot 'release-notes.txt') -Destination (Join-Path $RepositoryPath 'release-notes.txt')
            [IO.File]::WriteAllText((Join-Path $RepositoryPath 'version.txt'),$NextVersion,[Text.UTF8Encoding]::new($false))
            Invoke-CheckedGit -GitArguments @('add','--','release.ini','release-notes.txt','version.txt',('releases/' + $zipName)) | Out-Null
            Invoke-CheckedGit -GitArguments @('commit','-m',('Required CSR Tools update ' + $NextVersion)) | Out-Null
            Invoke-CheckedGit -GitArguments @('push','origin','main') | Out-Null
            [IO.File]::WriteAllText($mainPath,[IO.File]::ReadAllText($packagedMain),[Text.UTF8Encoding]::new($true))

            Write-Result 'PUBLISHED' "Published $NextVersion. Upgraded clients check within five minutes or at their next sign-in."
        }
    } elseif ($Mode -in @('Install','Verify')) {
        $settings = @{}
        foreach ($line in [IO.File]::ReadAllLines($ManifestPath)) {
            if ($line -match '^([^=]+)=(.*)$') { $settings[$matches[1]] = $matches[2] }
        }
        if ($settings.Version -notmatch '^\d+\.\d+\.\d+$' -or $settings.SHA256 -notmatch '^[0-9A-Fa-f]{64}$') { throw 'Invalid update manifest.' }
        $expectedUrl = 'https://raw.githubusercontent.com/ILoveYouBev/CSR-Tools/main/releases/CSRTools-' + $settings.Version + '.zip'
        if ($settings.Package -ne $expectedUrl) { throw 'The update package URL is not trusted.' }
        $stageRoot = Join-Path $env:TEMP ('CSRTools-update-' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $stageRoot | Out-Null
        $zip = Join-Path $stageRoot 'update.zip'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        if ($Mode -eq 'Verify') { Copy-Item -LiteralPath $PackagePath -Destination $zip }
        else { Invoke-WebRequest -Uri $settings.Package -OutFile $zip -UseBasicParsing -TimeoutSec 90 }
        if ((Get-CSRFileSHA256 -LiteralPath $zip) -ne $settings.SHA256) { throw 'Update checksum mismatch. No installed files were changed.' }
        Initialize-CSRZipRuntime
        $archive = [IO.Compression.ZipFile]::OpenRead($zip)
        try {
            $seen = @{}
            $totalBytes = 0L
            if ($archive.Entries.Count -gt 2048) { throw 'Too many package entries.' }
            foreach ($entry in $archive.Entries) {
                $relative = $entry.FullName.Replace('/','\')
                Resolve-SafeChild $stageRoot $relative | Out-Null
                if ($seen.ContainsKey($relative)) { throw 'Duplicate package path.' }
                $seen[$relative] = $true
                $totalBytes += $entry.Length
                if ($entry.Length -gt 52428800 -or $totalBytes -gt 134217728) { throw 'Oversized update package.' }
            }
        } finally { $archive.Dispose() }
        $unpacked = Join-Path $stageRoot 'package'
        [IO.Compression.ZipFile]::ExtractToDirectory($zip, $unpacked)
        $package = [IO.File]::ReadAllText((Join-Path $unpacked 'package-manifest.json')) | ConvertFrom-Json
        if ($package.version -ne $settings.Version) { throw 'Package version does not match the update manifest.' }
        $listed = @{}
        foreach ($file in $package.files) {
            $relative = [string]$file.path
            if ($UpdatePackage -and $relative -like 'Image Search/*') { throw 'Use the update ZIP from Distribution\Updates. It excludes image files so older installers preserve them.' }
            if ($relative -notin $requiredFiles -and $relative -notmatch '^Image Search/[^/\\]+\.png$|^Hotstrings/[^/\\]+\.txt$') { throw 'Unexpected package content.' }
            if ($listed.ContainsKey($relative)) { throw 'Duplicate file manifest entry.' }
            $listed[$relative] = $true
            $source = Resolve-SafeChild $unpacked $relative
            if ((Get-CSRFileSHA256 -LiteralPath $source) -ne $file.sha256) { throw "Package file checksum mismatch: $relative" }
        }
        foreach ($relative in $requiredFiles) { if (!$listed.ContainsKey($relative)) { throw "Incomplete update: $relative" } }
        $exeInfo = [Diagnostics.FileVersionInfo]::GetVersionInfo((Join-Path $unpacked 'CSR Tools.exe'))
        if ($exeInfo.ProductVersion -ne $settings.Version) { throw 'EXE version mismatch.' }
        $helperTokens = $null; $helperErrors = $null
        [Management.Automation.Language.Parser]::ParseFile((Join-Path $unpacked 'CSR Release.ps1'),[ref]$helperTokens,[ref]$helperErrors) | Out-Null
        if ($helperErrors.Count) { throw 'Package update helper is invalid.' }
        if ($Mode -eq 'Verify') { Write-Result 'VERIFIED' 'Package checksum, safe paths, contents and EXE version verified.'; exit 0 }
        if ($WaitPid -gt 0 -and (Get-Process -Id $WaitPid -ErrorAction SilentlyContinue)) { Wait-Process -Id $WaitPid -Timeout 60 -ErrorAction Stop }
        $lockPath = Join-Path $script:workspaceRoot '.csr-update.lock'
        $updateLock = [IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        $backupRoot = Join-Path $script:workspaceRoot ('_UpdateBackups\' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N'))
        $changed = [Collections.Generic.List[string]]::new()
        try {
            foreach ($file in $package.files) {
                $relative = [string]$file.path
                $dest = Resolve-SafeChild $script:workspaceRoot $relative
                if ($relative -eq 'Data.Ini') { continue }
                if ($relative -like 'Image Search/*' -and (Test-Path -LiteralPath $dest)) { continue }
                if ($relative -like 'Hotstrings/*' -and (Test-Path -LiteralPath $dest)) { continue }
                if ($relative -eq 'NSN_Substitute_Lookup/Substitutions.tsv' -and (Test-Path -LiteralPath $dest) -and (Test-Path -LiteralPath ($dest + '.edited'))) { continue }
                if ($relative -eq 'AverageWeights.tsv' -and (Test-Path -LiteralPath $dest) -and (Test-Path -LiteralPath ($dest + '.edited'))) { continue }
                if ($relative -eq 'ExtendedShelfLife.tsv' -and (Test-Path -LiteralPath $dest) -and (Test-Path -LiteralPath ($dest + '.edited'))) { continue }
                if (Test-Path -LiteralPath $dest) {
                    $backup = Resolve-SafeChild $backupRoot $relative
                    New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($backup)) -Force | Out-Null
                    Copy-Item -LiteralPath $dest -Destination $backup
                }
                $changed.Add($relative)
                New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($dest)) -Force | Out-Null
                Copy-Item -LiteralPath (Resolve-SafeChild $unpacked $relative) -Destination $dest -Force
            }
            $oldHotstring = Join-Path $script:workspaceRoot 'Hotstrings\-checknis.txt'
            if ((Test-Path -LiteralPath $oldHotstring) -and [IO.File]::ReadAllText($oldHotstring).Trim() -eq '=IFERROR(IF((D3-E3)=0,"",D3-E3),D3)') {
                New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
                Move-Item -LiteralPath $oldHotstring -Destination (Join-Path $backupRoot '-checknis.txt')
            }
        } catch {
            foreach ($relative in $changed) {
                $dest = Resolve-SafeChild $script:workspaceRoot $relative
                $backup = Resolve-SafeChild $backupRoot $relative
                if (Test-Path -LiteralPath $backup) { Copy-Item -LiteralPath $backup -Destination $dest -Force }
                elseif (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest }
            }
            throw
        } finally { $updateLock.Dispose() }
        Start-Process -FilePath (Join-Path $script:workspaceRoot 'CSR Tools.exe') -WindowStyle Hidden
        Write-Result 'INSTALLED' ('Installed ' + $settings.Version)
    } else { throw 'Choose a supported mode.' }
} catch {
    Write-Result 'FAILED' $_.Exception.Message
    if ($Mode -eq 'Install') {
        Add-Type -AssemblyName System.Windows.Forms
        [Windows.Forms.MessageBox]::Show(('The update could not be completed. ' + $_.Exception.Message + "`n`nYour account file and preferences were preserved. Result: " + $ResultPath),'CSR Tools update failed') | Out-Null
        $existingExe = Join-Path $script:workspaceRoot 'CSR Tools.exe'
        if (Test-Path -LiteralPath $existingExe) { Start-Process -FilePath $existingExe -WindowStyle Hidden }
        elseif ($AutoHotkeyPath -and (Test-Path -LiteralPath $AutoHotkeyPath)) { Start-Process -FilePath $AutoHotkeyPath -ArgumentList ('/restart "' + (Join-Path $script:workspaceRoot 'CSR TOOL 4.3.AHK') + '"') -WindowStyle Hidden }
    }
    if (!$ResultPath) { Write-Error $_ }
    exit 1
}
